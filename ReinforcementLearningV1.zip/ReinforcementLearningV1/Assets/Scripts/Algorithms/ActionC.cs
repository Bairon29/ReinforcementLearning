﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayGroundV3.Algorithms
{
    public class ActionC
    {
        private double reward;
        private int steps;
        private int actionMade;

        public double Reward { get => reward; set => reward = value; }
        public int ActionMade { get => actionMade; set => actionMade = value; }

        public ActionC(double reward, int actionMade)
        {
            this.reward = reward;
            this.actionMade = actionMade;
        }
    }
}
