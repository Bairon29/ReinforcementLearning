﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace PlayGroundV3.Algorithms
{
    public class EnvironmentSimulator
    {
        public int Score { get; internal set; }
        public StateOfEnv CurrentSnapShot { get; internal set; }
        public bool Dead { get; internal set; }
        public int SizeOfActions { get; internal set; }
        public int MapSize { get; internal set; }
        public int ROWS { get; internal set; }
        public int COLS { get; internal set; }

        public enum DIRECTIONS { LEFT, RIGHT, UP, DOWN };

        public EnvironmentSimulator(int sizeOfActions, int rows, int cols)
        {
            this.SizeOfActions = sizeOfActions;
            this.ROWS = rows;
            this.COLS = cols;
            this.MapSize = rows * cols;

            this.buildRandomMap();
        }

        public int[][] initializeMap()
        {
            int[][] map = new int[this.ROWS][];
            for(int i = 0; i < map.Length; i++)
            {
                map[i] = new int[this.COLS];
            }
            return map;
        }

        public void buildRandomMap()
        {
            int[][] map = this.initializeMap();
            Random ran = new Random();
            int xIndex = 1, yIndex = 1;
            int iterations = 0;
            while (iterations < this.MapSize)
            {
                DIRECTIONS d = directionsProbability(ran.NextDouble(), false);

                if(d == DIRECTIONS.DOWN && isValid(xIndex, yIndex + 1))
                {
                    yIndex++;
                }
                else if (d == DIRECTIONS.UP && isValid(xIndex, yIndex - 1))
                {
                    yIndex--;
                }

                if (isValid(xIndex, yIndex))
                {
                    map[yIndex][xIndex] = 1;
                }

                d = directionsProbability(ran.NextDouble(), true);

                if (d == DIRECTIONS.RIGHT && isValid(xIndex + 1, yIndex))
                {
                    xIndex++;
                }
                else if (d == DIRECTIONS.LEFT && isValid(xIndex - 1, yIndex))
                {
                    xIndex--;
                }

                if(isValid(xIndex, yIndex))
                {
                    map[yIndex][xIndex] = 1;
                }
                iterations++;
            }

            this.CurrentSnapShot = this.setAgentPosition(map);
        }

        public StateOfEnv setAgentPosition(int[][] map)
        {
            bool found = false;
            int xPos = 0;
            int yPos = 0;
            for (int i = 0; i < map.Length; i++)
            {
                for (int k = 0; k < map[i].Length; k++)
                {
                    if (map[i][k] == 1)
                    {
                        map[i][k] = 2;
                        xPos = k;
                        yPos = i;
                        found = true;
                        break;
                    }
                }
                if (found)
                {
                    break;
                }
            }

            map = this.setGoalPosition(map, xPos, yPos);
            return new StateOfEnv(map, xPos, yPos, (long)map.GetHashCode());
        }

        public int[][] setGoalPosition(int[][] map, int x, int y)
        {
            bool found = false;
            for (int i = map.Length - 1; i >= 0 ; i--)
            {
                for (int k = map[i].Length - 1; k >= 0; k--)
                {
                    if (map[i][k] == 1 && i != y && k != x)
                    {
                        map[i][k] = 3;
                        found = true;
                        break;
                    }
                }
                if (found)
                {
                    break;
                }
            }
            return map;
        }

        public DIRECTIONS directionsProbability(double p, bool horizontal)
        {
            DIRECTIONS d = DIRECTIONS.DOWN;

            if (horizontal)
            {
                if (p < .55)
                {
                    d = DIRECTIONS.RIGHT;
                }
                else
                {
                    d = DIRECTIONS.LEFT;
                }
            }
            else
            {
                if (p < .55)
                {
                    d = DIRECTIONS.DOWN;
                }
                else
                {
                    d = DIRECTIONS.UP;
                }
            }
            
            return d;
        }

        public bool isValid(int x, int y)
        {
            return (x < this.COLS - 1 && y < this.ROWS - 1 && x > 0 && y > 0);
        }

        public void printMap()
        {
            foreach(int[] item in this.CurrentSnapShot.SomeState)
            {
                for(int i = 0; i < item.Length; i++)
                {
                    Console.Write(" " + item[i] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}

