﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlayGroundV3.Algorithms
{
    public class StateOfEnv
    {
        int[][] someState;
        int agentPosX;
        int agentPosY;
        long uniqueMapIndetifier;
        public int[][] SomeState { get => someState; set => someState = value; }
        public int AgentPosX { get => agentPosX; set => agentPosX = value; }
        public int AgentPosY { get => agentPosY; set => agentPosY = value; }
        public long UniqueMapIndetifier { get => uniqueMapIndetifier; set => uniqueMapIndetifier = value; }

        public StateOfEnv(int[][] someState, int agentPosX, int agentPosY, long uniqueMapIndetifier)
        {
            this.someState = someState;
            this.agentPosX = agentPosX;
            this.agentPosY = agentPosY;
            this.uniqueMapIndetifier = uniqueMapIndetifier;
        }

        public StateOfEnv(int[][] someState, int agentPosX, int agentPosY)
        {
            this.someState = someState;
            this.agentPosX = agentPosX;
            this.agentPosY = agentPosY;
        }

        public StateOfEnv(int[][] someState, int agentPosX)
        {
            this.someState = someState;
            this.agentPosX = agentPosX;
        }

        public StateOfEnv(int[][] someState)
        {
            this.someState = someState;
        }
    }
}
