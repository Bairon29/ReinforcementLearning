﻿using PlayGroundV3.Algorithms;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PlayGroundV3.Algorithms
{
    public class QLearning
    {
        private Dictionary<StateOfEnv, Dictionary<int, ActionC>> qTable;

        private int cAction;
        private int pAction;
        private int pScore;
        private Random ran;
        private StateOfEnv cState;
        private StateOfEnv pState;
        private List<StateOfEnv> cSnapShot;
        private List<StateOfEnv> pSnapShot;
        private double probability;
        private bool learningStatus;

        private static int generations = 0;

        private const double discount = 0.9d;
        private const double epsilon = 0.0d;
        private const double learningRate = 0.9d;
        private int mapSize;
        private int ROWS;
        private int COLS;

        public int CAction { get => cAction; set => cAction = value; }
        public int PAction { get => pAction; set => pAction = value; }
        public Random Ran { get => ran; set => ran = value; }
        public StateOfEnv CState { get => cState; set => cState = value; }
        public StateOfEnv PState { get => pState; set => pState = value; }
        public double Probability { get => probability; set => probability = value; }
        public bool LearningStatus { get => learningStatus; set => learningStatus = value; }
        public static int Generations { get => generations; set => generations = value; }
        public int PScore { get => pScore; set => pScore = value; }
        internal Dictionary<StateOfEnv, Dictionary<int, ActionC>> QTable { get => qTable; set => qTable = value; }
        internal List<StateOfEnv> CSnapShot { get => cSnapShot; set => cSnapShot = value; }
        internal List<StateOfEnv> PSnapShot { get => pSnapShot; set => pSnapShot = value; }
        public int MapSize { get => mapSize; set => mapSize = value; }
        public int ROWS1 { get => ROWS; set => ROWS = value; }
        public int COLS1 { get => COLS; set => COLS = value; }

        public QLearning(int rows, int cols)
        {
            this.QTable = new Dictionary<StateOfEnv, Dictionary<int, ActionC>>();
            this.cAction = 0;
            this.pAction = 0;
            this.pScore = 0;
            this.mapSize = rows * cols;
            this.ROWS = rows;
            this.COLS = cols;
            this.ran = new Random();
            this.cState = null;
            this.pState = null;
            this.probability = 0.0d;
            this.learningStatus = true;
        }
        public QLearning(Dictionary<StateOfEnv, Dictionary<int, ActionC>> qTable, int cAction, int pAction,
            int pScore, Random ran, StateOfEnv cState, StateOfEnv pState, double probability,
            bool learningStatus)
        {
            this.QTable = qTable;
            this.cAction = cAction;
            this.pAction = pAction;
            this.pScore = pScore;
            this.ran = ran;
            this.cState = cState;
            this.pState = pState;
            this.probability = probability;
            this.learningStatus = learningStatus;
        }
        //actions are referred as which path would the agent would like to progress through
        public int getAction(EnvironmentSimulator env)
        {
            int reward = 0;
            if (env.Dead)
            {
                reward -= 1000;
            }
            else
            {
                reward += 200;
            }

            if (env.Score > this.pScore)
            {
                reward += 1000;
            }

            this.CState = env.CurrentSnapShot;
            /*this.CSnapShot = env.CurrentSnapShot;*/

            this.probability = this.ran.NextDouble();
            if (this.probability > QLearning.epsilon)
            {
                this.CAction = this.getMaxAction(CState).ActionMade;
            }
            else
            {
                this.CAction = this.ran.Next(4);
            }

            StateOfEnv cutt = this.getKeyFromQTable(this.CState);
            if (cutt == null)
            {
                Dictionary<int, ActionC> tempQTable = new Dictionary<int, ActionC>();
                //this should initialize to randon action. However, the amount of actoins
                //inputted should be equal to the number of choices presented by a state
                for (int i = 0; i < env.SizeOfActions; i++)
                {
                    tempQTable.Add(i, new ActionC(0D, i));
                }

                qTable.Add(this.cloneMap(this.CState), tempQTable);
            }

            if (this.PState != null && this.LearningStatus)
            {
                StateOfEnv cutt2 = this.getKeyFromQTable(this.PState);
                ActionC tempAction = null;
                if (this.qTable[cutt2] != null && this.qTable[cutt2].TryGetValue(this.PAction, out tempAction))
                {
                    double pQAS = tempAction.Reward;
                    /*tempAction.Reward = (pQAS + QLearning.learningRate * (reward + (QLearning.discount * this.getBestValue(this.CState).Reward) - pQAS));*/
                    tempAction.Reward = (((1 - QLearning.learningRate) * pQAS) + QLearning.learningRate * (reward + (QLearning.discount * this.getMaxAction(this.CState).Reward) - pQAS));
                    this.qTable[cutt2].Remove(this.PAction);
                    this.qTable[cutt2].Add(this.PAction, tempAction);
                }
            }
            this.PScore = env.Score;
            this.PAction = this.CAction;
            this.PState = this.cloneMap(this.CState);
            /* this.PSnapShot = this.copyListOfStateOfEnv(this.CSnapShot);*/
            return this.CAction;
        }

        private List<int> getState(List<float> currentState)
        {
            List<int> tempState = new List<int>();
            for (int i = 0; i < currentState.Count; i++)
            {
                tempState.Add((int)currentState[i]);
            }

            return tempState;
        }

        /*private ActionC getBestValue(List<int> currentState)
        {
            int actionAtMax = 0;
            double valueOfAction = 0.0;
            Dictionary<int, ActionC> tempAction;
            List<int> ls = getKeyFromQTable(currentState);
            if (ls != null)
            {
                qTable.TryGetValue(ls, out tempAction);
                for (int i = 0; i < tempAction.Count - 1; i++)
                {
                    if (tempAction[i].Reward > tempAction[i + 1].Reward)
                    {
                        valueOfAction = tempAction[i].Reward;
                        actionAtMax = tempAction[i].ActionMade;
                    }
                    else
                    {
                        valueOfAction = tempAction[i + 1].Reward;
                        actionAtMax = tempAction[i + 1].ActionMade;
                    }
                }

            }

            return new ActionC(valueOfAction, actionAtMax);
        }*/

        /*public List<StateOfEnv> copyListOfStateOfEnv(List<StateOfEnv> copy)
        {
            List<StateOfEnv> to = new List<StateOfEnv>();
            foreach (StateOfEnv item in copy)
            {
                to.Add(new StateOfEnv(new List<int>(item.SomeState), item.AgentPos));
            }

            return to;
        }*/

        public StateOfEnv getKeyFromQTable(StateOfEnv st)
        {
            List<StateOfEnv> ls1 = qTable.Keys.Select(x => x).ToList();
            StateOfEnv ls2 = null;
            foreach (StateOfEnv sb in ls1)
            {
                if (sb.UniqueMapIndetifier == st.UniqueMapIndetifier && sb.AgentPosX == st.AgentPosX && sb.AgentPosY == st.AgentPosY)
                {
                    ls2 = sb;
                }
            }
            return ls2;
        }

        /*public double maxActionHelper(StateOfEnv A, int initialPosX, int initialPosY, int firstIndex, int secondIndex)
        {
            double tempVal = A.SomeState[firstIndex][secondIndex] == 1 ? 0.0 : -300.0;
            if (Math.Abs(secondIndex - initialPos) > 0)
            {
                tempVal += Math.Abs(secondIndex - initialPos) * -50.0;
            }
            else
            {
                tempVal += -25.0;
            }

            return tempVal;
        }*/

        public int[] transformToState(StateOfEnv A, int posX, int posY)
        {
            int[] stateActions = new int[4];
            /*if(posX <= 0 || posY <= 0)
            {
                stateActions[0] = A.SomeState[posY][posX];
                stateActions[1] = A.SomeState[posY][posX];
                stateActions[2] = A.SomeState[posY][posX];
                stateActions[3] = A.SomeState[posY][posX];

                return stateActions;
            }*/
            stateActions[0] = A.SomeState[posY][posX - 1];
            stateActions[1] = A.SomeState[posY - 1][posX];
            stateActions[2] = A.SomeState[posY][posX + 1];
            stateActions[3] = A.SomeState[posY + 1][posX];

            return stateActions;
        }

        public int[][] assignPosition(int[][] pos, int posX, int posY)
        {
            for (int i = 0; i < pos.Length; i++)
            {
                pos[i] = new int[2];
            }
            pos[0][0] = posX - 1; pos[0][1] = posY;
            pos[1][0] = posX; pos[1][1] = posY - 1;
            pos[2][0] = posX + 1; pos[2][1] = posY;
            pos[3][0] = posX; pos[3][1] = posY + 1;

            return pos;
        }

        public int[] abjustPosition(int[] pos, int indexPos)
        {
            if (indexPos == 0)
            {
                pos[0] = pos[0] - 1;
            }
            else if (indexPos == 1)
            {
                pos[1] = pos[1] - 1;
            }
            else if (indexPos == 2)
            {
                pos[0] = pos[0] + 1;
            }
            else
            {
                pos[1] = pos[1] + 1;
            }


            return pos;
        }

        public double maxActionHelper(int[][] map, int i, int j)
        {
            double value = 0.0;
            if (!this.isValid(i, j) || map[j][i] == 0)
            {
                value += -(this.MapSize * 2);
            }
            else if (map[j][i] == 2)
            {
                value += -(this.MapSize / (this.MapSize / 4));
            }
            else if (map[j][i] == 3)
            {
                value += this.MapSize;
            }
            else
            {
                value += -.01D;
            }

            return value;
        }

        public double[] maxActionHelper(int[] stateActions, double[] stateWithValues)
        {
            for (int i = 0; i < stateActions.Length; i++)
            {
                if (stateActions[i] == 0)
                {
                    stateWithValues[i] += -this.MapSize * 2;
                }
                else if (stateActions[i] == 2)
                {
                    /*stateWithValues[i] += -(6 * 7 / (6 * 7 / 4));*/
                    stateWithValues[i] += -(this.MapSize / (this.MapSize / 4));
                }
                else if (stateActions[i] == 3)
                {
                    stateWithValues[i] += this.MapSize;
                }
                else
                {
                    stateWithValues[i] += -.01D;
                }
            }
            return stateWithValues;
        }

        public StateOfEnv cloneMap(StateOfEnv a)
        {
            int[][] ls = new int[a.SomeState.Length][];
            /*foreach (int[] item in a.SomeState)
            {
                ls.Add(new List<int>(item));
            }*/
            for (int i = 0; i < a.SomeState.Length; i++)
            {
                ls[i] = new int[a.SomeState[i].Length];
                Array.Copy(a.SomeState[i], ls[i], a.SomeState[i].Length);
            }
            return new StateOfEnv(ls, a.AgentPosX, a.AgentPosY, a.UniqueMapIndetifier);
        }

        /*public ActionC getMaxAction(StateOfEnv A)
        {
            int initialPosX = A.AgentPosX;
            int initialPosY = A.AgentPosY;
            double[] stateWithValues = new double[4];
            int[][] stateWithPositions = new int[4][];

            int[] stateActions = transformToState(A, initialPosX, initialPosY);

            stateWithValues = this.maxActionHelper(stateActions, stateWithValues);

            stateWithPositions = this.assignPosition(stateWithPositions, initialPosX, initialPosY);
            printMap(A);
            for (int i = 0; i < stateActions.Length; i++)
            {
                StateOfEnv a = this.cloneMap(A);
                var steps = 0;
                *//*while (stateWithValues[i] > -(6 * 7 - 2) && stateWithValues[i] < (6 * 7 - 2) && steps < 6 * 7)*//*
                while (a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] != 3 && stateWithValues[i] > -(this.MapSize - 2) && stateWithValues[i] < (this.MapSize - 2) && steps < this.MapSize - 2)
                {
                    a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] = 2;
                    stateActions = transformToState(a, stateWithPositions[i][0], stateWithPositions[i][1]);
                    double[] stateWithValuesTemp = this.maxActionHelper(stateActions, new double[stateWithValues.Length]);
                    int indexValue = this.maxValue(stateWithValuesTemp);
                    stateWithValues[i] += stateWithValuesTemp[indexValue];
                    stateWithPositions[i] = this.abjustPosition(stateWithPositions[i], indexValue);
                    steps++;
                    *//*Console.WriteLine("initial Pos: " + i + " took direction " + indexValue + " value " + stateWithValues[i]);*//*
                }
            }
            
            int maxIndex = this.maxValue(stateWithValues);

            return new ActionC(stateWithValues[maxIndex], maxIndex);
        }*/

        public ActionC getMaxAction(StateOfEnv A)
        {
            int initialPosX = A.AgentPosX;
            int initialPosY = A.AgentPosY;
            double[] stateWithValues = new double[4];
            int[][] stateWithPositions = new int[4][];

            stateWithPositions = this.assignPosition(stateWithPositions, initialPosX, initialPosY);
            StateOfEnv a = this.cloneMap(A);
            for (int i = 0; i < stateWithPositions.Length; i++)
            {
                stateWithValues[i] = this.maxActionHelper(a.SomeState, stateWithPositions[i][0], stateWithPositions[i][1]);
            }
            /*int[][] visited = new int[a.SomeState.Length][];
            for (int k = 0; k < visited.Length; k++)
            {
                visited[k] = new int[a.SomeState[k].Length];
            }*/
            printMap(A);
            for (int i = 0; i < stateWithPositions.Length; i++)
            {
                if (this.isValid(stateWithPositions[i][0], stateWithPositions[i][1])
                    && a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] == 1)
                {
                    stateWithValues[i] = this.maxPath(a.SomeState,
                        stateWithPositions[i][0], stateWithPositions[i][1], double.MinValue, stateWithValues[i], 10, 1);
                }
            }

            int maxIndex = this.maxValue(stateWithValues);
            Console.WriteLine("value: " + stateWithValues[maxIndex]);
            return new ActionC(stateWithValues[maxIndex], maxIndex);
        }

        public int maxValue(double[] stateWithValues)
        {
            int maxIndex = 0;
            for (int i = 1; i < stateWithValues.Length; i++)
            {
                if (stateWithValues[maxIndex] < stateWithValues[i])
                {
                    maxIndex = i;
                }
            }
            return maxIndex;
        }

        public void printMap(StateOfEnv a)
        {
            Console.WriteLine();
            Console.WriteLine();
            for (int k = 0; k < a.SomeState.Length; k++)
            {
                for (int i = 0; i < a.SomeState[k].Length; i++)
                {
                    Console.Write(" " + a.SomeState[k][i] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine();
        }
        /*public List<int> getKeyFromQTable(List<StateOfEnv> st)
        {
            List<List<int>> ls1 = qTable.Keys.Select(x => x).ToList();
            List<int> ls2 = null;
            foreach (List<int> sb in ls1)
            {
                bool eqs = sb.SequenceEqual(st);
                if (eqs)
                {
                    ls2 = sb;
                }
            }
            return ls2;
        }*/


        public double maxPath(int[][] map,
                        int i, int j, double maxValue, double value, int maxStep, int steps)
        {
            // if goal is reached then return max value
            if (map[j][i] == 3 || steps >= maxStep)
            {
                return Math.Max(value, maxValue);
            }

            // Set as visited (temporary)
            map[j][i] = 2;

            // BOTTOM
            if (isValid(i, j + 1) && isPreferredCell(map, i, j + 1))
            {
                maxValue = maxPath(map, i, j + 1,
                                            maxValue, value + maxActionHelper(map, i, j + 1), maxStep, steps + 1);
            }

            // RIGHT
            if (isValid(i + 1, j) && isPreferredCell(map, i + 1, j))
            {

                maxValue = maxPath(map, i + 1, j,
                                            maxValue, value + maxActionHelper(map, i + 1, j), maxStep, steps + 1);
            }

            // LEFT
            if (isValid(i - 1, j) && isPreferredCell(map, i - 1, j))
            {
                maxValue = maxPath(map, i - 1, j,
                                            maxValue, value + maxActionHelper(map, i - 1, j), maxStep, steps + 1);
            }

            // UP
            if (isValid(i, j - 1) && isPreferredCell(map, i, j - 1))
            {
                maxValue = maxPath(map, i, j - 1,
                                            maxValue, value + maxActionHelper(map, i, j - 1), maxStep, steps + 1);
            }

            // Remove temporary visited cells
            map[j][i] = 1;

            return maxValue;
        }
        public int[][] backTrackMap(int[][] map, int j, int i)
        {
            map[j][i] = 1;
            return map;
        }
        public double maxPath(int[][] map,
                    int i, int j, double maxValue, double value, int maxStep, int steps)
        {
            // if goal is reached then return max value
            if (map[j][i] == 3 || steps >= maxStep)
            {
                return Math.Max(value, maxValue);
            }

            // Set as visited (temporary)
            map[j][i] = 2;

/*
            return this.isValid(i, j + 1) ? maxPath(hep(map, j + 1, i), i, j + 1, *//*Bottom*//*
                                        this.isValid(i + 1, j) ? maxPath(hep(map, j, i + 1), i + 1, j, *//*RIGHT*//*
                                            this.isValid(i - 1, j) ? maxPath(hep(map, j, i - 1), i - 1, j, *//*LEFT*//*
                                                    this.isValid(i, j - 1) ? maxPath(hep(map, j - 1, i), i, j - 1, *//*UP*//*
                                                        maxValue,
                                                    value + maxActionHelper(hep(map, j - 1, i), i, j - 1), maxStep, steps + 1) : maxValue, *//*End UP*//*
                                                value + maxActionHelper(hep(map, j, i - 1), i - 1, j), maxStep, steps + 1) : maxValue, *//*End LEFT*//*
                                            value + maxActionHelper(hep(map, j, i + 1), i + 1, j), maxStep, steps + 1) : maxValue, *//*End RIGHT*//*
                                        value + maxActionHelper(hep(map, j + 1, i), i, j + 1), maxStep, steps + 1) : maxValue; *//*End Bottom*/
            if (this.isValid(i, j + 1)) /*Bottom*/
            {
                return maxPath(backTrackMap(map, j + 1, i), i, j + 1, /*BOTTOM*/
                                        this.isValid(i + 1, j) ? maxPath(backTrackMap(map, j, i + 1), i + 1, j, /*RIGHT*/
                                            this.isValid(i - 1, j) ? maxPath(backTrackMap(map, j, i - 1), i - 1, j, /*LEFT*/
                                                    this.isValid(i, j - 1) ? maxPath(backTrackMap(map, j - 1, i), i, j - 1, /*UP*/
                                                        maxValue,
                                                    value + maxActionHelper(backTrackMap(map, j - 1, i), i, j - 1), maxStep, steps + 1) : maxValue, /*End UP*/
                                                value + maxActionHelper(backTrackMap(map, j, i - 1), i - 1, j), maxStep, steps + 1) : maxValue, /*End LEFT*/
                                            value + maxActionHelper(backTrackMap(map, j, i + 1), i + 1, j), maxStep, steps + 1) : maxValue, /*End RIGHT*/
                                        value + maxActionHelper(backTrackMap(map, j + 1, i), i, j + 1), maxStep, steps + 1); /*END BOTTOM*/
            }
            else if (this.isValid(i + 1, j)) /*RIGHT*/
            {
                return maxPath(backTrackMap(map, j, i + 1), i + 1, j, /*RIGHT*/
                                        this.isValid(i, j + 1) ? maxPath(backTrackMap(map, j + 1, i), i, j + 1, /*BOTTOM*/
                                            this.isValid(i - 1, j) ? maxPath(backTrackMap(map, j, i - 1), i - 1, j, /*LEFT*/
                                                    this.isValid(i, j - 1) ? maxPath(backTrackMap(map, j - 1, i), i, j - 1, /*UP*/
                                                        maxValue,
                                                    value + maxActionHelper(backTrackMap(map, j - 1, i), i, j - 1), maxStep, steps + 1) : maxValue, /*End UP*/
                                                value + maxActionHelper(backTrackMap(map, j, i - 1), i - 1, j), maxStep, steps + 1) : maxValue, /*End LEFT*/
                                            value + maxActionHelper(backTrackMap(map, j + 1, i), i, j + 1), maxStep, steps + 1) : maxValue, /*End BOTTOM*/
                                        value + maxActionHelper(backTrackMap(map, j, i + 1), i + 1, j), maxStep, steps + 1); /*End RIGHT*/
            }
            else if (this.isValid(i - 1, j)) /*LEFT*/
            {
                return maxPath(backTrackMap(map, j, i - 1), i - 1, j, /*LEFT*/
                                        this.isValid(i + 1, j) ? maxPath(backTrackMap(map, j, i + 1), i + 1, j, /*RIGHT*/
                                            this.isValid(i, j + 1) ? maxPath(backTrackMap(map, j + 1, i), i, j + 1, /*BOTTOM*/
                                                    this.isValid(i, j - 1) ? maxPath(backTrackMap(map, j - 1, i), i, j - 1, /*UP*/
                                                        maxValue,
                                                    value + maxActionHelper(backTrackMap(map, j - 1, i), i, j - 1), maxStep, steps + 1) : maxValue, /*End UP*/
                                                value + maxActionHelper(backTrackMap(map, j + 1, i), i, j + 1), maxStep, steps + 1) : maxValue, /*End BOTTOM*/
                                            value + maxActionHelper(backTrackMap(map, j, i + 1), i + 1, j), maxStep, steps + 1) : maxValue, /*End RIGHT*/
                                        value + maxActionHelper(backTrackMap(map, j, i - 1), i - 1, j), maxStep, steps + 1); /*End LEFT*/
            }
            else if (this.isValid(i, j - 1)) /*UP*/
            {
                return maxPath(backTrackMap(map, j - 1, i), i, j - 1, /*UP*/
                                        this.isValid(i + 1, j) ? maxPath(backTrackMap(map, j, i + 1), i + 1, j, /*RIGHT*/
                                            this.isValid(i - 1, j) ? maxPath(backTrackMap(map, j, i - 1), i - 1, j, /*LEFT*/
                                                    this.isValid(i, j + 1) ? maxPath(backTrackMap(map, j + 1, i), i, j + 1, /*BOTTOM*/
                                                        maxValue,
                                                    value + maxActionHelper(backTrackMap(map, j + 1, i), i, j + 1), maxStep, steps + 1) : maxValue, /*End BOTTOM*/
                                                value + maxActionHelper(backTrackMap(map, j, i - 1), i - 1, j), maxStep, steps + 1) : maxValue, /*End LEFT*/
                                            value + maxActionHelper(backTrackMap(map, j, i + 1), i + 1, j), maxStep, steps + 1) : maxValue, /*End RIGHT*/
                                        value + maxActionHelper(backTrackMap(map, j - 1, i), i, j - 1), maxStep, steps + 1); /*End UP*/
            }

            // Remove temporary visited cells
            map[j][i] = 1;

            return maxValue;
        }


        private bool isPreferredCell(int[][] mat, int x, int y)
        {
            return !(mat[y][x] == 0 || mat[y][x] == 2);
        }

        // if not a valid position, return false
        private bool isValid(int x, int y)
        {
            return (y < this.ROWS && x < this.COLS && x >= 0 && y >= 0);
        }
    }
}
