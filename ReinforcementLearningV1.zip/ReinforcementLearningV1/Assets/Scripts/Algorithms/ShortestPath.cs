﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayGroundV3.Algorithms
{
    class ShortestPath
    {
        // M x N matrix
        private const int M = 6;
        private const int N = 10;

        // Check if it is possible to go to (x, y) from current position. The
        // function returns false if the cell has value 0 or already visited
        private static bool isSafe(int[][] mat, int[][] visited, int x, int y)
        {
            return !(mat[y][x] == 0 || visited[y][x] != 0);
        }

        // if not a valid position, return false
        private static bool isValid(int x, int y)
        {
            return (y < M && x < N && x >= 0 && y >= 0);
        }

        // Find Shortest Possible Route in a Matrix mat from source cell (0, 0)
        // to destination cell (x, y)

        // 'min_dist' stores length of longest path from source to destination
        // found so far and 'dist' maintains length of path from source cell to
        // the current cell (i, j)

        /*public int findShortestPath(int[][] mat, int[][] visited,
                         int i, int j, int x, int y, int min_dist, int dist)
        {
            // if destination is found, update min_dist
            if (i == x && j == y)
            {
                return Math.Min(dist, min_dist);
            }

            // set (i, j) cell as visited
            visited[i][j] = 1;

            // go to bottom cell
            if (isValid(i + 1, j) && isSafe(mat, visited, i + 1, j))
            {

                min_dist = findShortestPath(mat, visited, i + 1, j, x, y,
                                            min_dist, dist + 1);
            }

            // go to right cell
            if (isValid(i, j + 1) && isSafe(mat, visited, i, j + 1))
            {
                min_dist = findShortestPath(mat, visited, i, j + 1, x, y,
                                            min_dist, dist + 1);
            }

            // go to top cell
            if (isValid(i - 1, j) && isSafe(mat, visited, i - 1, j))
            {
                min_dist = findShortestPath(mat, visited, i - 1, j, x, y,
                                            min_dist, dist + 1);
            }

            // go to left cell
            if (isValid(i, j - 1) && isSafe(mat, visited, i, j - 1))
            {
                min_dist = findShortestPath(mat, visited, i, j - 1, x, y,
                                            min_dist, dist + 1);
            }

            // Backtrack - Remove (i, j) from visited matrix
            visited[i][j] = 0;

            return min_dist;
        }*/

        public double maxActionHelper(int[][] map, int i, int j)
        {
            double value = 0.0;
            if (map[j][i] == 0)
            {
                value += -(M * N * 2);
            }
            else if (map[j][i] == 2)
            {
                value += -((M * N) / ((M * N) / 4));
            }
            else if (map[j][i] == 3)
            {
                value += M * N;
            }
            else
            {
                value += -.01D;
            }

            return value;
        }

        public double findShortestPath(int[][] mat, int[][] visited,
                        int i, int j, double min_dist, double dist)
        {
            // if destination is found, update min_dist
            if (mat[j][i] == 3)
            {
                return Math.Max(dist, min_dist);
            }

            // set (i, j) cell as visited
            visited[j][i] = 1;

            // go to bottom cell
            if (isValid(i, j + 1) && isSafe(mat, visited, i, j + 1))
            {
                min_dist = findShortestPath(mat, visited, i, j + 1,
                                            min_dist, dist + maxActionHelper(mat, i, j + 1));
            }

            // go to right cell
            if (isValid(i + 1, j) && isSafe(mat, visited, i + 1, j))
            {

                min_dist = findShortestPath(mat, visited, i + 1, j,
                                            min_dist, dist + maxActionHelper(mat, i + 1, j));
            }

            // go to left cell
            if (isValid(i - 1, j) && isSafe(mat, visited, i - 1, j))
            {
                min_dist = findShortestPath(mat, visited, i - 1, j,
                                            min_dist, dist + maxActionHelper(mat, i - 1, j));
            }

            // go to up cell
            if (isValid(i, j - 1) && isSafe(mat, visited, i, j - 1))
            {
                min_dist = findShortestPath(mat, visited, i, j - 1, 
                                            min_dist, dist + maxActionHelper(mat, i, j - 1));
            }

            // Backtrack - Remove (i, j) from visited matrix
            visited[j][i] = 0;

            return min_dist;
        }

        /*public static void main(String[] args)
        {
            int[][] mat =
            {
                new int[]{ 1, 1, 1, 1, 1, 0, 0, 1, 1, 1 },
                new int[]{ 0, 1, 1, 1, 1, 1, 0, 1, 0, 1 },
                new int[]{ 0, 0, 1, 0, 1, 1, 1, 0, 0, 1 },
                new int[]{ 1, 0, 1, 1, 1, 0, 1, 1, 0, 1 },
                new int[]{ 0, 0, 0, 1, 0, 0, 0, 1, 0, 1 },
                new int[]{ 1, 0, 1, 1, 1, 0, 0, 1, 1, 0 },
                new int[]{ 0, 0, 0, 0, 1, 0, 0, 1, 0, 1 },
                new int[]{ 0, 1, 1, 1, 1, 1, 1, 1, 0, 0 },
                new int[]{ 1, 1, 1, 1, 1, 0, 0, 1, 1, 1 },
                new int[]{ 0, 0, 1, 0, 0, 1, 1, 0, 0, 1 },
            };

            // construct a matrix to keep track of visited cells
            int[][] visited = new int[M][];
            for (int i = 0; i < visited.Length; i++)
            {
                visited[i] = new int[N];
            }

            int min_dist = findShortestPath(mat, visited, 0, 0, 7, 5,
                                            int.MaxValue, 0);

            if (min_dist != int.MaxValue)
            {
                Console.WriteLine("The shortest path from source to destination "
                                  + "has length " + min_dist);
            }
            else
            {
                Console.WriteLine("Destination can't be reached from source");
            }
        }*/
    }
}
