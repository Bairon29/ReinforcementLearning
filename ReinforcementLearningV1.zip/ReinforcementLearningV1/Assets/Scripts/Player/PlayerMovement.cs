﻿using PlayGroundV3.Algorithms;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public bool canProcess = true;
    public bool goalReached = false;
    GameObject target = null;
    // Start is called before the first frame update
    void Start()
    {
        canProcess = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.CompareTag("Goal"))
        {
            goalReached = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(target != null && !canProcess)
        {
            float dist = Vector3.Distance(target.transform.position, transform.position);
            if(dist <= .2f)
            {
                canProcess = true;
            }
        }
    }


    public void move(List<List<GameObject>> wallList, int action, EnvironmentSimulator env)
    {
        canProcess = false;
        GameObject pos = null;
        print("action move: " + action);
        if (action == 0)
        {
            int p = env.CurrentSnapShot.AgentPosX;
            if (p - 1 > 0)
            {
                pos = wallList[env.CurrentSnapShot.AgentPosY][p - 1];
                env.CurrentSnapShot.AgentPosX += -1;
            }
        }
        else if (action == 1)
        {
            int p = env.CurrentSnapShot.AgentPosY;
            if (p - 1 > 0)
            {
                pos = wallList[p - 1][env.CurrentSnapShot.AgentPosX];
                env.CurrentSnapShot.AgentPosY += -1;
            }
        }
        else if (action == 2)
        {
            int p = env.CurrentSnapShot.AgentPosX;
            if (p + 1 < wallList[0].Count - 1)
            { 
                pos = wallList[env.CurrentSnapShot.AgentPosY][p + 1];
                env.CurrentSnapShot.AgentPosX += 1;
            }
        }
        else
        {
            int p = env.CurrentSnapShot.AgentPosY;
            if (p + 1 < wallList.Count - 1)
            {
                pos = wallList[p + 1][env.CurrentSnapShot.AgentPosX];
                env.CurrentSnapShot.AgentPosY += 1;
            }
        }
        //transform.position = Vector3.Lerp(transform.position, pos.transform.position, 1000f * Time.deltaTime);
        transform.position = pos.transform.position;
        target = pos;
        if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] != 3)
        {
            env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] = 2;
        }
    }
}
