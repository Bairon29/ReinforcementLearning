﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Walls : MonoBehaviour
{
    //public GameObject wall;
    //public Transform floor;
    // Start is called before the first frame update
    List<List<GameObject>> wallList;

    public List<List<GameObject>> WallList { get => wallList; set => wallList = value; }

    public GameObject buildMap(int[][] map, GameObject wall, Transform floor, GameObject player, GameObject goal)
    {
        wallList = new List<List<GameObject>>();
        //Instantiate(wall, new Vector3(transform.position.x - 4.5f, 0.5f, transform.position.z - 4.5f), Quaternion.identity, transform);
        //Instantiate(wall, new Vector3(transform.position.x - 3.5f, 0.5f, 0), Quaternion.identity, transform);
        int rows = 0;
        GameObject target = null;
        for (float i = -4.5f; i <= 4.5f; i+= 1)
        {
            int cols = 0;
            wallList.Add(new List<GameObject>());
            
            for (float x = -4.5f; x <= 4.5f; x += 1)
            {
                GameObject Obj = null;
                if (rows < map.Length && cols < map[rows].Length && map[rows][cols] == 2)
                {
                    Obj = Instantiate(player, new Vector3(floor.position.x - x, 0.5f, floor.position.z - i), Quaternion.identity) as GameObject;
                    Obj.transform.Rotate(0f, -90f, 0f, Space.World);
                    Obj.GetComponent<BoxCollider>().isTrigger = true;
                }
                else if(rows < map.Length && cols < map[rows].Length && map[rows][cols] == 3)
                {
                    Obj = Instantiate(goal, new Vector3(floor.position.x - x, 0.5f, floor.position.z - i), Quaternion.identity) as GameObject;
                    Obj.transform.Rotate(0f, -90f, 0f, Space.World);
                    target = Obj;
                    /*Obj.GetComponent<BoxCollider>().isTrigger = true;
                    Obj.GetComponent<Renderer>().material.color = Color.yellow;
                    Obj.transform.localScale = new Vector3(.25f, .25f, .25f);*/
                }
                else
                {
                    Obj = Instantiate(wall, new Vector3(floor.position.x - x, 0.5f, floor.position.z - i), Quaternion.identity) as GameObject;
                    Obj.transform.Rotate(0f, -90f, 0f, Space.World);
                    if (rows < map.Length && cols < map[rows].Length && map[rows][cols] == 1)
                    {
                        Obj.SetActive(false);
                    }
                }
                
                WallList[rows].Add(Obj);
                cols++;
            }
            rows++;
        }
        return target;
    }
}
