﻿using PlayGroundV3.Algorithms;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject wall;
    public Transform floor;
    // Start is called before the first frame update

    const int ROWS = 10;
    const int COLS = 10;
    
    QLearning qLearing;
    EnvironmentSimulator env;
    Walls buildWall;
    public GameObject player;
    public GameObject goal;
    GameObject mutablePlayer;
    PlayerMovement pMovement;
    GameObject target;
    float delayTimer = 0f;
    float maxDelayTimer = .5f;
    void Start()
    {
        
        qLearing = new QLearning(ROWS, COLS);
        env = new EnvironmentSimulator(4, ROWS, COLS);
        buildWall = new Walls();
        target = buildWall.buildMap(env.CurrentSnapShot.SomeState, wall, floor, player, goal);
        mutablePlayer = GameObject.FindWithTag("Player");
        if (mutablePlayer == null)
        {
            print("Not Found");
        }
        pMovement = mutablePlayer.GetComponent<PlayerMovement>();
        /* for (int i = 0; i < env.CurrentSnapShot.SomeState.Length; i++)
         {
             for(int x = 0; x < env.CurrentSnapShot.SomeState[i].Length; x++)
             {
                 print(" " + env.CurrentSnapShot.SomeState[i][x] + " ");
             }
             print("\n");
         }*/
    }

    // Update is called once per frame
    void Update()
    {
        delayTimer += Time.deltaTime;
        if (!pMovement.goalReached && pMovement.canProcess && delayTimer > maxDelayTimer)
        {
            delayTimer = 0f;
            float dist = Vector3.Distance(target.transform.position, player.transform.position);

            int action = qLearing.getAction(env);

            pMovement.move(buildWall.WallList, action, env);
        }
    }
}
