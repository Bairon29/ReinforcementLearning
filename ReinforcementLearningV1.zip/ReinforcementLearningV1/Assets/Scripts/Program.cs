﻿

using PlayGroundV3.Algorithms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PlayGroundV3
{
    class Program
    {
        public int MapSize { get; set; }
        
        public Program(int mapSize)
        {
            this.MapSize = mapSize;
        }
        /*private Dictionary<StateOfEnv, Dictionary<int, ActionC>> qTable;*/
        static void Main(string[] args)
        {
            StateOfEnv intArray = new StateOfEnv(new int[][] {
                                                            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                                            new int[] { 0, 1, 1, 0, 0, 1, 1, 1, 1, 0 },
                                                            new int[] { 0, 1, 1, 1, 3, 0, 1, 1, 1, 0 },
                                                            new int[] { 0, 0, 3, 0, 1, 1, 1, 0, 0, 0 },
                                                            new int[] { 0, 0, 1, 1, 1, 0, 1, 1, 1, 0 },
                                                            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }}, 1, 1);
            int ROWS = 10, COLS = 10;
            EnvironmentSimulator env = new EnvironmentSimulator(4, ROWS, COLS);
            env.printMap();
            
            /*int[][] mat =
            {
                new int[]{ 1, 1, 1, 1, 1, 0, 0, 1, 1, 1 },
                new int[]{ 0, 1, 1, 1, 1, 1, 0, 1, 0, 1 },
                new int[]{ 0, 0, 1, 0, 1, 1, 1, 0, 0, 1 },
                new int[]{ 1, 0, 1, 1, 1, 0, 1, 1, 0, 1 },
                new int[]{ 0, 0, 0, 1, 0, 0, 0, 1, 0, 1 },
                new int[]{ 1, 0, 1, 1, 1, 0, 0, 1, 1, 0 },
                new int[]{ 0, 0, 0, 0, 1, 0, 0, 1, 0, 1 },
                new int[]{ 0, 1, 1, 1, 1, 1, 1, 1, 0, 0 },
                new int[]{ 1, 1, 1, 1, 1, 0, 0, 1, 1, 1 },
                new int[]{ 0, 0, 1, 0, 0, 1, 1, 0, 0, 1 },
            };
            const int M = 6;
            const int N = 10;
            ShortestPath s = new ShortestPath();
            QLearning ql = new QLearning(6, 10);
            // construct a matrix to keep track of visited cells
            int[][] visited = new int[M][];
            for (int i = 0; i < visited.Length; i++)
            {
                visited[i] = new int[N];
            }
            double min_dist = s.findShortestPath(intArray.SomeState, visited, 1, 1,
                                            double.MinValue, 0D);

            if (min_dist != double.MinValue)
            {
                Console.WriteLine("The shortest path from source to destination "
                                  + "has length " + min_dist);
            }
            else
            {
                Console.WriteLine("Destination can't be reached from source");
            }*/



            intArray.UniqueMapIndetifier = intArray.GetHashCode();

            /*intArray.SomeState[1][1] = 2;
            env.CurrentSnapShot = intArray;*/
            QLearning ql = new QLearning(ROWS, COLS);
            Program p = new Program(ROWS * COLS);

            int action = ql.getAction(env);
            p.helper(action, env);


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }



            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }


            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }
            else
            {
                action = ql.getAction(env);
                p.helper(action, env);
            }
        }

        public void helper(int action, EnvironmentSimulator env)
        {
            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 0)
            {
                env.Dead = false;
                env.Score = 0;
                return;
            }
            else if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] == 3)
            {
                Console.WriteLine("Goal Reached");
                return;
            }

            env.Dead = true;
            env.Score += 2;

            if (action == 0)
            {
                int pos = env.CurrentSnapShot.AgentPosX;
                if (pos - 1 > 0)
                {
                    env.CurrentSnapShot.AgentPosX += -1;
                    Console.WriteLine("Left");
                }

            }
            else if (action == 1)
            {
                int pos = env.CurrentSnapShot.AgentPosY;
                if (pos - 1 > 0)
                {
                    env.CurrentSnapShot.AgentPosY += -1;
                    Console.WriteLine("Up");
                }

            }
            else if (action == 2)
            {
                int pos = env.CurrentSnapShot.AgentPosX;
                if (pos + 1 < env.CurrentSnapShot.SomeState[0].Length - 1)
                {
                    env.CurrentSnapShot.AgentPosX += 1;
                    Console.WriteLine("Right");
                }
            }
            else
            {
                int pos = env.CurrentSnapShot.AgentPosY;
                if (pos + 1 < env.CurrentSnapShot.SomeState.Length - 1)
                {
                    env.CurrentSnapShot.AgentPosY += 1;
                    Console.WriteLine("Down");
                }
            }

            if (env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] != 3)
            {
                env.CurrentSnapShot.SomeState[env.CurrentSnapShot.AgentPosY][env.CurrentSnapShot.AgentPosX] = 2;
            }
        }



        public int[] transformToState(StateOfEnv A, int posX, int posY)
        {
            int[] stateActions = new int[4];
            /*if(posX <= 0 || posY <= 0)
            {
                stateActions[0] = A.SomeState[posY][posX];
                stateActions[1] = A.SomeState[posY][posX];
                stateActions[2] = A.SomeState[posY][posX];
                stateActions[3] = A.SomeState[posY][posX];

                return stateActions;
            }*/
            stateActions[0] = A.SomeState[posY][posX - 1];
            stateActions[1] = A.SomeState[posY - 1][posX];
            stateActions[2] = A.SomeState[posY][posX + 1];
            stateActions[3] = A.SomeState[posY + 1][posX];

            return stateActions;
        }

        public int[][] assignPosition(int[][] pos, int posX, int posY)
        {
            for (int i = 0; i < pos.Length; i++)
            {
                pos[i] = new int[2];
            }
            pos[0][0] = posX - 1; pos[0][1] = posY;
            pos[1][0] = posX; pos[1][1] = posY - 1;
            pos[2][0] = posX + 1; pos[2][1] = posY;
            pos[3][0] = posX; pos[3][1] = posY + 1;

            return pos;
        }

        public int[] abjustPosition(int[] pos, int indexPos)
        {
            if (indexPos == 0)
            {
                pos[0] = pos[0] - 1;
            }
            else if (indexPos == 1)
            {
                pos[1] = pos[1] - 1;
            }
            else if (indexPos == 2)
            {
                pos[0] = pos[0] + 1;
            }
            else
            {
                pos[1] = pos[1] + 1;
            }


            return pos;
        }
        public double[] maxActionHelper(int[] stateActions, double[] stateWithValues)
        {
            for (int i = 0; i < stateActions.Length; i++)
            {
                if (stateActions[i] == 0)
                {
                    stateWithValues[i] += -this.MapSize * 2;
                }
                else if (stateActions[i] == 2)
                {
                    /*stateWithValues[i] += -(6 * 7 / (6 * 7 / 4));*/
                    stateWithValues[i] += -this.MapSize;
                }
                else if (stateActions[i] == 3)
                {
                    stateWithValues[i] += this.MapSize;
                }
                else
                {
                    stateWithValues[i] += -.01D;
                }
            }
            return stateWithValues;
        }

        /*public StateOfEnv cloneMap(StateOfEnv a)
        {
            List<List<int>> ls = new List<List<int>>();
            foreach (List<int> item in a.SomeState)
            {
                ls.Add(new List<int>(item));
            }

            return new StateOfEnv(ls, a.AgentPosX, a.AgentPosY, a.UniqueMapIndetifier);
        }*/

        /*public ActionC getMaxAction(StateOfEnv A)
        {
            int initialPosX = A.AgentPosX;
            int initialPosY = A.AgentPosY;
            double[] stateWithValues = new double[4];
            int[][] stateWithPositions = new int[4][];

            int[] stateActions = transformToState(A, initialPosX, initialPosY);

            stateWithValues = this.maxActionHelper(stateActions, stateWithValues);

            stateWithPositions = this.assignPosition(stateWithPositions, initialPosX, initialPosY);
            PrintingMap(A);
            for (int i = 0; i < stateActions.Length; i++)
            {
                StateOfEnv a = this.cloneMap(A);
                var steps = 0;
                *//*while (stateWithValues[i] > -(6 * 7 - 2) && stateWithValues[i] < (6 * 7 - 2) && steps < 6 * 7)*//*
                while (a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] != 3 && stateWithValues[i] > -(this.MapSize - 2) && stateWithValues[i] < (this.MapSize - 2) && steps < this.MapSize - 2)
                {
                    a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] = 2;
                    stateActions = transformToState(a, stateWithPositions[i][0], stateWithPositions[i][1]);
                    double[] stateWithValuesTemp = this.maxActionHelper(stateActions, new double[stateWithValues.Length]);
                    int indexValue = this.maxValue(stateWithValuesTemp);
                    stateWithValues[i] += stateWithValuesTemp[indexValue];
                    stateWithPositions[i] = this.abjustPosition(stateWithPositions[i], indexValue);
                    steps++;
                    *//*Console.WriteLine("initial Pos: " + i + " took direction " + indexValue + " value " + stateWithValues[i]);*//*
                }
            }

            int maxIndex = this.maxValue(stateWithValues);

            return new ActionC(stateWithValues[maxIndex], maxIndex);
        }*/

        public double getMaxActionRecursiveHelper(int[] stateActions, int[][] stateWithPositions, StateOfEnv a)
        {
            /*for(int i = 0; i < stateActions.Length; i++)
            {
                if()
                if(a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] == 0)
                {
                    continue;
                }
                else if (a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] == 3)
                {

                }
            }*/
            return -1.0D;
        }



        /*public ActionC getMaxAction(StateOfEnv A)
        {
            int initialPosX = A.AgentPosX;
            int initialPosY = A.AgentPosY;
            double[] stateWithValues = new double[4];
            int[][] stateWithPositions = new int[4][];

            int[] stateActions = transformToState(A, initialPosX, initialPosY);

            stateWithValues = this.maxActionHelper(stateActions, stateWithValues);

            stateWithPositions = this.assignPosition(stateWithPositions, initialPosX, initialPosY);
            PrintingMap(A);
            for (int i = 0; i < stateActions.Length; i++)
            {
                StateOfEnv a = this.cloneMap(A);
                var steps = 0;
                *//*while (stateWithValues[i] > -(6 * 7 - 2) && stateWithValues[i] < (6 * 7 - 2) && steps < 6 * 7)*//*
                while (a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] != 3 && stateWithValues[i] > -(this.MapSize - 2) && stateWithValues[i] < (this.MapSize - 2) && steps < this.MapSize - 2)
                {
                    a.SomeState[stateWithPositions[i][1]][stateWithPositions[i][0]] = 2;
                    stateActions = transformToState(a, stateWithPositions[i][0], stateWithPositions[i][1]);
                    double[] stateWithValuesTemp = this.maxActionHelper(stateActions, new double[stateWithValues.Length]);
                    int indexValue = this.minValue(stateWithValuesTemp);
                    stateWithValues[i] += stateWithValuesTemp[indexValue];
                    stateWithPositions[i] = this.abjustPosition(stateWithPositions[i], indexValue);
                    steps++;
                    *//*Console.WriteLine("initial Pos: " + i + " took direction " + indexValue + " value " + stateWithValues[i]);*//*
                }
            }

            int maxIndex = this.minValue(stateWithValues);

            return new ActionC(stateWithValues[maxIndex], maxIndex);
        }*/

        public int maxValue(double[] stateWithValues)
        {
            int maxIndex = 0;
            for (int i = 1; i < stateWithValues.Length; i++)
            {
                if (stateWithValues[maxIndex] < stateWithValues[i])
                {
                    maxIndex = i;
                }
            }
            return maxIndex;
        }
    }
}
